package com.cg.sprint.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.sprint.entity.Refund;

public interface RefundDao extends JpaRepository<Refund, Integer>{

}
